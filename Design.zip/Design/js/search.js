var currentScrollBarValue = 0;
function restrictScroll(e){
	e.preventDefault();
}

function popupOpen()
{
document.getElementById('popup').setAttribute("class", "demoVisible overlay");
document.addEventListener("wheel", restrictScroll, false);
//document.body.style.overflow = 'hidden';
}
function popupClose()
{
document.getElementById('popup').setAttribute("class", "demoHidden overlay");
document.removeEventListener("wheel", restrictScroll, false);
//document.body.style.overflow = 'visible';
}